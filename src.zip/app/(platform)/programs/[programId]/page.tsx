"use client";

import React, { useState, useEffect, useCallback, use } from "react";
import Link from "next/link";

type ProgramType = "GROUP" | "INDIVIDUAL" | "HYBRID";
type ProgramStatus = "ACTIVE" | "INACTIVE" | "COMPLETED" | "CANCELLED";

interface Staff {
    id: string;
    firstName: string;
    lastName: string;
    role: string;
}

interface Enrollment {
    id: string;
    patientId: string;
    status: "ACTIVE" | "DISCHARGED" | "COMPLETED";
    enrolledAt: string;
    dischargedAt: string | null;
    patient: {
        id: string;
        firstName: string;
        lastName: string;
        dateOfBirth: string | null;
        status: string;
        folder: { folderNumber: string };
    };
}

interface Program {
    id: string;
    name: string;
    description: string | null;
    programType: ProgramType;
    status: ProgramStatus;
    startDate: string | null;
    endDate: string | null;
    metadata: any;
    createdBy: { id: string; firstName: string; lastName: string };
    enrollments: Enrollment[];
    _count: { notes: number };
}

interface Patient {
    id: string;
    firstName: string;
    lastName: string;
    folder: { folderNumber: string };
}

const typeStyle: Record<ProgramType, { color: string; bg: string; icon: string; label: string }> = {
    GROUP:      { color: "#6B5ED4", bg: "#EDEBFB", icon: "👥", label: "Group" },
    INDIVIDUAL: { color: "#2C7A6E", bg: "#E6F4F2", icon: "🧠", label: "Individual" },
    HYBRID:     { color: "#D98326", bg: "#FEF3E2", icon: "🔄", label: "Hybrid" },
};

const statusChip = (s: string) => {
    if (s === "ACTIVE" || s === "active") return "chip-active";
    if (s === "INACTIVE" || s === "inactive") return "chip-inactive";
    if (s === "COMPLETED" || s === "completed") return "chip-progress";
    if (s === "CANCELLED" || s === "cancelled") return "chip-critical";
    return "chip-pending";
};

/* ─── Enrol Patient Modal ─── */
function EnrolPatientModal({ programId, onClose, onEnrolled }: { programId: string, onClose: () => void, onEnrolled: (e: Enrollment) => void }) {
    const [patients, setPatients] = useState<Patient[]>([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [selectedPatientId, setSelectedPatientId] = useState("");

    useEffect(() => {
        const fetchPatients = async () => {
            try {
                const res = await fetch("http://localhost:5000/patients", { credentials: "include" });
                const data = await res.json();
                if (!res.ok) throw new Error(data.message || "Failed to fetch patients.");
                setPatients(data.data || []);
            } catch (e: any) {
                setError(e.message);
            } finally { setLoading(false); }
        };
        fetchPatients();
    }, []);

    const handleEnrol = async () => {
        if (!selectedPatientId) return;
        setSaving(true); setError(null);
        try {
            const res = await fetch(`http://localhost:5000/programs/${programId}/enroll`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({ patientId: selectedPatientId }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message || "Enrollment failed.");
            onEnrolled(data.data);
            onClose();
        } catch (e: any) {
            setError(e.message);
        } finally { setSaving(false); }
    };

    return (
        <div style={{ position: "fixed", inset: 0, background: "rgba(25,40,37,0.58)", backdropFilter: "blur(4px)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }} onClick={e => e.target === e.currentTarget && onClose()}>
            <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 18, width: "100%", maxWidth: 460, boxShadow: "0 28px 72px rgba(25,40,37,0.22)", overflow: "hidden" }}>
                <div style={{ padding: "20px 24px", borderBottom: "1px solid var(--border)", background: "var(--primary-xlight)", display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
                    <div>
                        <div style={{ fontFamily: "'Fraunces', serif", fontSize: 18, fontWeight: 700, color: "var(--fg)" }}>Enrol Patient</div>
                        <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 2 }}>Select a patient to join this program</div>
                    </div>
                    <button onClick={onClose} style={{ width: 32, height: 32, border: "1.5px solid var(--border)", borderRadius: 8, background: "var(--card)", cursor: "pointer", fontSize: 15, color: "var(--muted)", display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
                </div>
                <div style={{ padding: "24px" }}>
                    {error && <div style={{ background: "var(--danger-light)", color: "var(--danger)", padding: 12, borderRadius: 8, marginBottom: 16, fontSize: 13 }}>⚠️ {error}</div>}
                    <div className="form-group">
                        <label className="form-label">Patient Name</label>
                        <select className="form-input" value={selectedPatientId} onChange={e => setSelectedPatientId(e.target.value)} disabled={loading || saving}>
                            <option value="">Select a patient...</option>
                            {patients.map(p => (
                                <option key={p.id} value={p.id}>{p.firstName} {p.lastName} ({p.folder?.folderNumber || p.id})</option>
                            ))}
                        </select>
                        {loading && <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 4 }}>Loading patients...</div>}
                    </div>
                </div>
                <div style={{ padding: "14px 24px", borderTop: "1px solid var(--border)", display: "flex", justifyContent: "flex-end", gap: 10 }}>
                    <button onClick={onClose} style={{ padding: "10px 18px", border: "1.5px solid var(--border)", borderRadius: 9, background: "var(--card)", cursor: "pointer", fontSize: 13, fontWeight: 700, color: "var(--fg-mid)" }}>Cancel</button>
                    <button onClick={handleEnrol} disabled={!selectedPatientId || saving} style={{ padding: "10px 22px", border: "none", borderRadius: 9, background: "var(--primary)", cursor: "pointer", fontSize: 13, fontWeight: 700, color: "#fff", opacity: (saving || !selectedPatientId) ? 0.6 : 1 }}>{saving ? "Enrolling..." : "Confirm Enrollment"}</button>
                </div>
            </div>
        </div>
    );
}

/* ─── Edit Program Modal ─── */
function EditProgramModal({ program, onClose, onUpdated }: { program: Program, onClose: () => void, onUpdated: (p: Program) => void }) {
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [form, setForm] = useState({
        name: program.name,
        description: program.description || "",
        status: program.status,
        programType: program.programType,
        startDate: program.startDate ? new Date(program.startDate).toISOString().split('T')[0] : "",
        endDate: program.endDate ? new Date(program.endDate).toISOString().split('T')[0] : "",
    });

    const handleUpdate = async () => {
        setSaving(true); setError(null);
        try {
            const res = await fetch(`http://localhost:5000/programs/${program.id}`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify(form),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message || "Update failed.");
            onUpdated(data.data);
            onClose();
        } catch (e: any) {
            setError(e.message);
        } finally { setSaving(false); }
    };

    return (
        <div style={{ position: "fixed", inset: 0, background: "rgba(25,40,37,0.58)", backdropFilter: "blur(4px)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }} onClick={e => e.target === e.currentTarget && onClose()}>
            <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 18, width: "100%", maxWidth: 560, boxShadow: "0 28px 72px rgba(25,40,37,0.22)", overflow: "hidden" }}>
                <div style={{ padding: "20px 24px", borderBottom: "1px solid var(--border)", background: "var(--primary-xlight)", display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
                    <div style={{ fontFamily: "'Fraunces', serif", fontSize: 18, fontWeight: 700 }}>Edit Program Settings</div>
                    <button onClick={onClose} style={{ width: 32, height: 32, border: "1.5px solid var(--border)", borderRadius: 8, background: "var(--card)", cursor: "pointer" }}>✕</button>
                </div>
                <div style={{ padding: "24px", display: "flex", flexDirection: "column", gap: 14 }}>
                    {error && <div style={{ background: "var(--danger-light)", color: "var(--danger)", padding: 12, borderRadius: 8 }}>⚠️ {error}</div>}
                    <div className="form-group">
                        <label className="form-label">Program Name</label>
                        <input className="form-input" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Description</label>
                        <textarea className="form-input" rows={3} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                        <div className="form-group">
                            <label className="form-label">Type</label>
                            <select className="form-input" value={form.programType} onChange={e => setForm(p => ({ ...p, programType: e.target.value as ProgramType }))}>
                                <option value="GROUP">Group</option>
                                <option value="INDIVIDUAL">Individual</option>
                                <option value="HYBRID">Hybrid</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Status</label>
                            <select className="form-input" value={form.status} onChange={e => setForm(p => ({ ...p, status: e.target.value as ProgramStatus }))}>
                                <option value="ACTIVE">Active</option>
                                <option value="INACTIVE">Inactive</option>
                                <option value="COMPLETED">Completed</option>
                                <option value="CANCELLED">Cancelled</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div style={{ padding: "14px 24px", borderTop: "1px solid var(--border)", display: "flex", justifyContent: "flex-end", gap: 10 }}>
                    <button onClick={onClose} style={{ padding: "10px 18px", border: "1.5px solid var(--border)", borderRadius: 9 }}>Cancel</button>
                    <button onClick={handleUpdate} disabled={saving} style={{ padding: "10px 22px", border: "none", borderRadius: 9, background: "var(--primary)", color: "#fff" }}>{saving ? "Saving..." : "Save Changes"}</button>
                </div>
            </div>
        </div>
    );
}

export default function ProgramDetailPage({ params: paramsPromise }: { params: Promise<{ programId: string }> }) {
    const params = use(paramsPromise);
    const { programId } = params;

    const [program, setProgram] = useState<Program | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [activeTab, setActiveTab] = useState("Overview");
    const [showEnrolModal, setShowEnrolModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);

    const fetchProgram = useCallback(async () => {
        try {
            setLoading(true); setError(null);
            const res = await fetch(`http://localhost:5000/programs/${programId}`, { credentials: "include" });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message || "Failed to load program.");
            setProgram(data.data);
        } catch (e: any) {
            setError(e.message);
        } finally { setLoading(false); }
    }, [programId]);

    useEffect(() => { fetchProgram(); }, [fetchProgram]);

    const handleDischarge = async (patientId: string) => {
        if (!confirm("Are you sure you want to discharge this patient?")) return;
        try {
            const res = await fetch(`http://localhost:5000/programs/${programId}/patients/${patientId}`, {
                method: "DELETE",
                credentials: "include",
            });
            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.message || "Discharge failed.");
            }
            fetchProgram();
        } catch (e: any) {
            alert(e.message);
        }
    };

    if (loading) return <div style={{ padding: 40, textAlign: "center", color: "var(--muted)" }}>Loading program details...</div>;
    if (error || !program) return <div style={{ padding: 40, textAlign: "center", color: "var(--danger)" }}>⚠️ {error || "Program not found."}</div>;

    const ts = typeStyle[program.programType];
    const enrollments = program.enrollments || [];
    const activeEnrollments = enrollments.filter(e => e.status === "ACTIVE");

    return (
        <>
            {showEnrolModal && <EnrolPatientModal programId={programId} onClose={() => setShowEnrolModal(false)} onEnrolled={fetchProgram} />}
            {showEditModal && <EditProgramModal program={program} onClose={() => setShowEditModal(false)} onUpdated={fetchProgram} />}

            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 20, fontSize: 13, color: "var(--muted)" }}>
                <Link href="/programs" style={{ color: "var(--primary)", textDecoration: "none", fontWeight: 700 }}>← Programs</Link>
                <span>/</span>
                <span style={{ color: "var(--fg)", fontWeight: 600 }}>{program.name}</span>
            </div>

            <div className="card" style={{ marginBottom: 24, overflow: "hidden" }}>
                <div style={{ height: 5, background: ts.color }} />
                <div style={{ padding: 28 }}>
                    <div style={{ display: "flex", gap: 24, alignItems: "flex-start" }}>
                        <div style={{ width: 64, height: 64, borderRadius: 16, background: `${ts.color}14`, border: `1.5px solid ${ts.color}30`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28 }}>{ts.icon}</div>
                        <div style={{ flex: 1 }}>
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                                <div>
                                    <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: 24, fontWeight: 700, marginBottom: 6 }}>{program.name}</h1>
                                    <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                                        <span className={`chip ${statusChip(program.status)}`}>{program.status}</span>
                                        <span style={{ fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 20, background: ts.bg, color: ts.color, fontFamily: "'Space Mono', monospace" }}>{ts.label}</span>
                                        <span style={{ fontSize: 12.5, color: "var(--muted)" }}>Lead: <strong>{program.createdBy.firstName} {program.createdBy.lastName}</strong></span>
                                    </div>
                                </div>
                                <div style={{ display: "flex", gap: 8 }}>
                                    <button onClick={() => setShowEditModal(true)} style={{ padding: "8px 14px", border: "1.5px solid var(--border)", borderRadius: 9, background: "var(--card)", cursor: "pointer", fontSize: 12.5, fontWeight: 700 }}>✏️ Edit</button>
                                    <button onClick={() => setShowEnrolModal(true)} style={{ padding: "8px 16px", border: "none", borderRadius: 9, background: "var(--primary)", color: "#fff", fontWeight: 700, cursor: "pointer", boxShadow: "0 2px 8px rgba(44,122,110,0.25)" }}>+ Enrol Patient</button>
                                </div>
                            </div>
                            <div style={{ marginTop: 20, paddingTop: 20, borderTop: "1px solid var(--border)", display: "flex", gap: 32 }}>
                                {[
                                    { label: "Enrolled", value: activeEnrollments.length },
                                    { label: "Notes", value: program._count.notes },
                                    { label: "Start Date", value: program.startDate ? new Date(program.startDate).toLocaleDateString() : "—" },
                                    { label: "End Date", value: program.endDate ? new Date(program.endDate).toLocaleDateString() : "—" },
                                ].map(s => (
                                    <div key={s.label}>
                                        <div style={{ fontSize: 9, fontFamily: "'Space Mono', monospace", color: "var(--muted)", textTransform: "uppercase", marginBottom: 4 }}>{s.label}</div>
                                        <div style={{ fontSize: 14, fontWeight: 700 }}>{s.value}</div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div style={{ display: "flex", gap: 4, marginBottom: 20, background: "var(--card)", border: "1px solid var(--border)", borderRadius: 11, padding: 4, width: "fit-content" }}>
                {["Overview", "Enrolled Patients", "Attendance"].map(t => (
                    <button key={t} onClick={() => setActiveTab(t)} style={{ padding: "8px 18px", borderRadius: 8, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 700, background: activeTab === t ? "var(--primary)" : "transparent", color: activeTab === t ? "#fff" : "var(--muted)" }}>{t}</button>
                ))}
            </div>

            {activeTab === "Overview" && (
                <div style={{ display: "grid", gridTemplateColumns: "1fr 400px", gap: 20 }}>
                    <div className="card" style={{ padding: 24 }}>
                        <h3 style={{ fontFamily: "'Fraunces', serif", marginBottom: 12 }}>Description</h3>
                        <p style={{ color: "var(--fg-mid)", lineHeight: 1.6 }}>{program.description || "No description provided for this program."}</p>
                    </div>
                    <div className="card" style={{ padding: 24 }}>
                        <h3 style={{ fontFamily: "'Fraunces', serif", marginBottom: 12 }}>Program Details</h3>
                        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                            <div style={{ display: "flex", justifyContent: "space-between" }}>
                                <span style={{ color: "var(--muted)" }}>Type</span>
                                <span style={{ fontWeight: 600 }}>{program.programType}</span>
                            </div>
                            <div style={{ display: "flex", justifyContent: "space-between" }}>
                                <span style={{ color: "var(--muted)" }}>Status</span>
                                <span style={{ fontWeight: 600 }}>{program.status}</span>
                            </div>
                            <div style={{ display: "flex", justifyContent: "space-between" }}>
                                <span style={{ color: "var(--muted)" }}>Created By</span>
                                <span style={{ fontWeight: 600 }}>{program.createdBy.firstName} {program.createdBy.lastName}</span>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === "Enrolled Patients" && (
                <div className="card">
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Patient</th>
                                <th>Folder #</th>
                                <th>Enrolled Date</th>
                                <th>Status</th>
                                <th style={{ textAlign: "right" }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {enrollments.length === 0 ? (
                                <tr><td colSpan={5} style={{ textAlign: "center", padding: 40, color: "var(--muted)" }}>No patients enrolled in this program.</td></tr>
                            ) : enrollments.map(e => (
                                <tr key={e.id}>
                                    <td>
                                        <Link href={`/patients/${e.patientId}`} style={{ textDecoration: "none" }}>
                                            <div style={{ fontWeight: 700, color: "var(--fg)" }}>{e.patient.firstName} {e.patient.lastName}</div>
                                            <div style={{ fontSize: 10, color: "var(--muted)" }}>{e.patientId}</div>
                                        </Link>
                                    </td>
                                    <td className="td-mono">{e.patient.folder?.folderNumber || "—"}</td>
                                    <td className="td-mono">{new Date(e.enrolledAt).toLocaleDateString()}</td>
                                    <td><span className={`chip ${e.status === "ACTIVE" ? "chip-active" : "chip-inactive"}`}>{e.status}</span></td>
                                    <td style={{ textAlign: "right" }}>
                                        {e.status === "ACTIVE" && (
                                            <button onClick={() => handleDischarge(e.patientId)} style={{ padding: "5px 10px", border: "1.5px solid var(--danger-light)", borderRadius: 7, background: "var(--danger-light)", color: "var(--danger)", fontWeight: 700, cursor: "pointer" }}>Discharge</button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {activeTab === "Attendance" && (
                <div style={{ padding: 40, textAlign: "center", color: "var(--muted)" }} className="card">
                    <div style={{ fontSize: 32, marginBottom: 12 }}>📅</div>
                    <p>Attendance tracking for group sessions is coming soon.</p>
                </div>
            )}
        </>
    );
}